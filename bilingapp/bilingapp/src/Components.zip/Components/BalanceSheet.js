// src/pages/BalanceSheet.jsx
import React from "react";

const BalanceSheet = () => {
  return (
    <div className="p-6" style={{paddingLeft:"100px"}}>
      <h1 className="text-2xl font-bold mb-4">Balance Sheet</h1>
      <p>This is where your balance sheet info will go.</p>
    </div>
  );
};

export default BalanceSheet;
