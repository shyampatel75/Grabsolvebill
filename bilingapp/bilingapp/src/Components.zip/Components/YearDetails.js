import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";

const YearDetails = () => {
  const { yearRange } = useParams();
  const [invoices, setInvoices] = useState([]);
  const [filteredInvoices, setFilteredInvoices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [filterType, setFilterType] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    if (!yearRange || !yearRange.match(/^\d{4}-\d{4}$/)) {
      setError("Invalid year range format. Please use 'YYYY-YYYY'.");
      setLoading(false);
      return;
    }

    const fetchInvoices = async () => {
      setLoading(true);
      setError("");
      try {
        const response = await fetch(`http://localhost:8000/api/invoices`);
        if (!response.ok) throw new Error(`HTTP Error: ${response.status}`);
        const data = await response.json();

        // Extract year range
        const [startYear, endYear] = yearRange.split("-").map(Number);

        // Filter based on financial year (April to March)
        const filteredByYear = data.filter((invoice) => {
          const date = new Date(invoice.invoice_date);
          const year = date.getFullYear();
          const month = date.getMonth() + 1; // Jan = 0

          // April to December = current year (startYear), Jan to March = next year (endYear)
          if (month >= 4) {
            return year === startYear;
          } else {
            return year === endYear;
          }
        });

        setInvoices(filteredByYear);
        setFilteredInvoices(filteredByYear);
      } catch (error) {
        setError("Failed to fetch data. Please try again later.");
        console.error("Error fetching invoices:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchInvoices();
  }, [yearRange]);

  // Filter by name or date
  useEffect(() => {
    let result = invoices;

    if (filterType === "name") {
      result = invoices.filter((invoice) =>
        invoice.buyer_name?.toLowerCase().startsWith(searchTerm.toLowerCase())
      );
    } else if (filterType === "date") {
      result = invoices.filter((invoice) => invoice.invoice_date === searchTerm);
    }

    setFilteredInvoices(result);
  }, [searchTerm, filterType, invoices]);

  return (
    <div style={{ height: "100vh" }}>
      <div className="d-flex justify-content-end align-items-center pt-2 pb-2 px-4">
        <div className="d-flex align-items-center">
          <select
            className="form-select me-2"
            style={{ width: "180px" }}
            value={filterType}
            onChange={(e) => {
              setFilterType(e.target.value);
              setSearchTerm("");
            }}
          >
            <option value="">Filter By</option>
            <option value="name">Search by Name</option>
            <option value="date">Search by Date</option>
          </select>

          {filterType === "name" && (
            <input
              type="text"
              className="form-control"
              placeholder="Enter name to search"
              style={{ width: "220px", marginRight: "15px" }}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          )}

          {filterType === "date" && (
            <input
              type="date"
              className="form-control"
              style={{ width: "220px" }}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          )}
        </div>

        <button
          onClick={() => navigate("/tax-invoice")}
          type="button"
          className="naw-biladd"
        >
          <i className="bi bi-plus-lg"></i> New Bills
        </button>
      </div>

      <div style={{ padding: "10px 21px 10px 82px" }}>
        <h2>Year: {yearRange}</h2>
        <div style={{ borderRadius: "10px", overflow: "hidden" }}>
          {loading ? (
            <div className="text-center">Loading...</div>
          ) : error ? (
            <div className="text-center text-danger">{error}</div>
          ) : (
            <table className="table table-striped table-hover text-center">
              <thead className="table-dark">
                <tr>
                  <th>No.</th>
                  <th>Name</th>
                  <th>Bill Number</th>
                  <th>Country</th>
                  <th>Date</th>
                  <th>View</th>
                  <th>Download</th>
                </tr>
              </thead>
              <tbody>
                {filteredInvoices.length === 0 ? (
                  <tr>
                    <td colSpan="7" className="text-center">
                      No data found.
                    </td>
                  </tr>
                ) : (
                  filteredInvoices.map((invoice, index) => (
                    <tr key={invoice.id}>
                      <td>{index + 1}</td>
                      <td>{invoice.buyer_name}</td>
                      <td>{invoice.invoice_number}</td>
                      <td>{invoice.country}</td>
                      <td>{invoice.invoice_date}</td>
                      <td>
                        <button
                          className="btn btn-primary"
                          onClick={() => navigate(`/bills/${invoice.buyer_name}`)}
                        >
                          View
                        </button>
                      </td>
                      <td>
                        <button
                          className="btn btn-success"
                          onClick={() =>
                            alert(`Downloading Bill: ${invoice.invoice_number}`)
                          }
                        >
                          Download
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
};

export default YearDetails;