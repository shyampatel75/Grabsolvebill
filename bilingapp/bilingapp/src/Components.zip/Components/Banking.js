import React, { useEffect, useState } from 'react';

const Banking = () => {
  const [visibleButton, setVisibleButton] = useState(null);
  const [buyerNames, setBuyerNames] = useState([]);
  const [selectedBuyer, setSelectedBuyer] = useState("");
  const [selectedDate, setSelectedDate] = useState("");
  const [notice, setNotice] = useState("");
  const [depositAmount, setDepositAmount] = useState("");

  const [companyName, setCompanyName] = useState("");
  const [companyDate, setCompanyDate] = useState("");
  const [companyAmount, setCompanyAmount] = useState("");

  const [salaryName, setSalaryName] = useState("");
  const [salaryAmount, setSalaryAmount] = useState("");
  const [salaryDate, setSalaryDate] = useState("");

  const [otherDate, setOtherDate] = useState("");
  const [otherNotice, setOtherNotice] = useState("");
  const [otherAmount, setOtherAmount] = useState("");

  useEffect(() => {
    if (visibleButton === 2 || visibleButton === 3) {
      fetch("http://localhost:8000/api/invoices/")
        .then((res) => res.json())
        .then((data) => {
          const names = data.map(item => item.buyer_name);
          const uniqueNames = [...new Set(names)];
          setBuyerNames(uniqueNames);
        })
        .catch((error) => {
          console.error("Error fetching names:", error);
        });
    }
  }, [visibleButton]);

  return (
    <div className="p-6 max-w-md mx-auto" style={{ paddingLeft: "100px" }}>
      <div className="d-flex justify-content-around gap-2 mb-4 my-4">
        <button
          className="bg-blue-500 text-white px-4 py-2 rounded"
          onClick={() => setVisibleButton(1)}
        >
          Company Bill
        </button>
        <button
          className="bg-green-500 text-white px-4 py-2 rounded"
          onClick={() => setVisibleButton(2)}
        >
          Buyer
        </button>
        <button
          className="bg-yellow-500 text-white px-4 py-2 rounded"
          onClick={() => setVisibleButton(3)}
        >
          Salary
        </button>
        <button
          className="bg-red-500 text-white px-4 py-2 rounded"
          onClick={() => setVisibleButton(4)}
        >
          Other
        </button>
      </div>

      <div className="mt-4">
        {visibleButton === 1 && (
          <>
            <h3 className="mb-2 font-semibold">Buyer</h3>
            <select
              className="border px-4 py-2 rounded w-full mb-3"
              value={selectedBuyer}
              onChange={(e) => setSelectedBuyer(e.target.value)}
            >
              <option value="">-- Select Buyer --</option>
              {buyerNames.map((name, index) => (
                <option key={index} value={name}>{name}</option>
              ))}
            </select>
            <input
              type="date"
              className="border px-4 py-2 rounded w-full mb-3"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
            />
            <input
              type="text"
              placeholder="Enter notice"
              className="border px-4 py-2 rounded w-full mb-3"
              value={notice}
              onChange={(e) => setNotice(e.target.value)}
            />
            <input
              type="number"
              placeholder="Enter deposit amount"
              className="border px-4 py-2 rounded w-full mb-3"
              value={depositAmount}
              onChange={(e) => setDepositAmount(e.target.value)}
            />
          </>
        )}

        {visibleButton === 2 && (
         <>
         <h3 className="mb-2 font-semibold">Company Bill</h3>
         <input
           type="text"
           placeholder="Enter name"
           className="border px-4 py-2 rounded w-full mb-3"
           value={companyName}
           onChange={(e) => setCompanyName(e.target.value)}
         />
         <input
           type="date"
           className="border px-4 py-2 rounded w-full mb-3"
           value={companyDate}
           onChange={(e) => setCompanyDate(e.target.value)}
         />
         <input
           type="number"
           placeholder="Enter amount"
           className="border px-4 py-2 rounded w-full mb-3"
           value={companyAmount}
           onChange={(e) => setCompanyAmount(e.target.value)}
         />
       </>
        )}

        {visibleButton === 3 && (
          <>
            <h3 className="mb-2 font-semibold">Salary</h3>
            <select
              className="border px-4 py-2 rounded w-full mb-3"
              value={salaryName}
              onChange={(e) => setSalaryName(e.target.value)}
            >
              <option value="">-- Select Employee --</option>
              {buyerNames.map((name, index) => (
                <option key={index} value={name}>{name}</option>
              ))}
            </select>
            <input
              type="number"
              placeholder="Enter amount"
              className="border px-4 py-2 rounded w-full mb-3"
              value={salaryAmount}
              onChange={(e) => setSalaryAmount(e.target.value)}
            />
            <input
              type="date"
              className="border px-4 py-2 rounded w-full mb-3"
              value={salaryDate}
              onChange={(e) => setSalaryDate(e.target.value)}
            />
          </>
        )}

        {visibleButton === 4 && (
          <>
            <h3 className="mb-2 font-semibold">Other</h3>
            <input
              type="date"
              className="border px-4 py-2 rounded w-full mb-3"
              value={otherDate}
              onChange={(e) => setOtherDate(e.target.value)}
            />
            <input
              type="text"
              placeholder="Enter notice"
              className="border px-4 py-2 rounded w-full mb-3"
              value={otherNotice}
              onChange={(e) => setOtherNotice(e.target.value)}
            />
            <input
              type="number"
              placeholder="Enter amount"
              className="border px-4 py-2 rounded w-full mb-3"
              value={otherAmount}
              onChange={(e) => setOtherAmount(e.target.value)}
            />
          </>
        )}
      </div>
    </div>
  );
};

export default Banking;
