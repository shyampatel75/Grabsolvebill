import React, { useEffect, useState } from "react";
import "./Taxinvoice.css";
import { useNavigate } from "react-router-dom";

const Clients = () => {
  const navigate = useNavigate();
  const [invoices, setInvoices] = useState([]);

  useEffect(() => {
    fetch("http://localhost:8000/api/invoices/") // 🔁 Replace with your actual API endpoint
      .then((res) => res.json())
      .then((data) => {
        setInvoices(data);
      })
      .catch((err) => console.error("Error fetching invoices:", err));
  }, []);

  const handleView = (name) => {
    navigate(`/view-invoice/${encodeURIComponent(name)}`);
  };

  const handleDownload = (billNumber) => {
    alert(`Downloading Bill: ${billNumber}`);
  };

  return (
    <div style={{ height: "100vh"}}>
      <div style={{ paddingLeft: "100px" }}>
        <div style={{ padding: "20px" }}>
          <div className="d-grid gap-2 d-md-flex justify-content-md-end pt-2 pb-2 px-4">
            <button
              onClick={() => navigate("/tax-invoice")}
              type="button"
              className="naw-biladd"
            >
              <i className="bi bi-plus-lg" style={{ fontWeight: "700" }}></i>{" "}
              New Bills
            </button>
          </div>

          <h2>Dashboard</h2>

          <div style={{ borderRadius: "10px", overflow: "hidden" }}>
            <table className="table table-hover text-center">
              <thead style={{ backgroundColor: "#6c7ae0", color: "#fff" }}>
                <tr>
                  <th>No.</th>
                  <th>Name</th>
                  <th>Bill Number</th>
                  <th>Amount</th>
                  <th>Date</th>
                  <th>Items</th>
                </tr>
              </thead>
              <tbody>
                {invoices.map((invoice, index) => (
                  <tr key={`${invoice.id}-${index}`}>
                    <td>{index + 1}</td>
                    <td>{invoice.buyer_name}</td>
                    <td>{invoice.invoice_number}</td>
                    <td>{parseFloat(invoice.total_with_gst).toFixed(2)}</td>
                    <td>{invoice.invoice_date}</td>
                    <td className="buttongrup">
                      <button
                        className="viewbutton"
                        onClick={() => handleView(invoice.buyer_name)}
                      >
                        View
                      </button>
                      <button
                        className="downloadbutton"
                        onClick={() => handleDownload(invoice.invoice_number)}
                      >
                        Download
                      </button>
                      <button
                        className="newaddbillbutton"
                        onClick={() => navigate("/tax-invoice")}
                      >
                        Newbill
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

        </div>
      </div>
    </div>
  );
};

export default Clients;