import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const Address = () => {
  const navigate = useNavigate();
  const [invoices, setInvoices] = useState([]);

  useEffect(() => {
    fetch("http://localhost:8000/api/invoices/")
      .then((res) => res.json())
      .then((data) => setInvoices(data))
      .catch((err) => console.error("Error fetching invoices:", err));
  }, []);

  const handleDownload = (billNumber) => {
    alert(`Downloading Bill: ${billNumber}`);
  };

  return (
    <div className="containers" style={{ height: "100vh" }}>
      <div className="d-grid gap-2 d-md-flex justify-content-md-end pt-2 pb-2 px-4">
        <button
          type="button"
          className="naw-biladd"
          onClick={() => navigate("/tax-invoice")}
        >
          <i className="bi bi-plus-lg"></i> New Bills
        </button>
      </div>

      <div style={{ padding: "10px 21px 10px 82px" }}>
        <div style={{ borderRadius: "32px", overflow: "hidden" ,border:"15px solid"}}>
          <table className="table table-striped table-hover text-center">
            <thead className="table-dark">
              <tr>
                <th>No.</th>
                <th>Buyer Name</th>
                <th>Buyer Address</th>
                <th>Total Amount</th>
                <th>View</th>
                <th>Download</th>
              </tr>
            </thead>
            <tbody>
              {invoices.map((invoice, index) => (
                <tr key={invoice.id}>
                  <td>{index + 1}</td>
                  <td>{invoice.buyer_name}</td>
                  <td
                    className="truncate address-hover"
                    title={invoice.buyer_address}
                    onClick={() => {
                      navigator.clipboard.writeText(invoice.buyer_address);
                      alert("Address copied to clipboard!");
                    }}
                  >
                    {invoice.buyer_address.length > 20
                      ? invoice.buyer_address.slice(0, 20) + "..."
                      : invoice.buyer_address}
                  </td>
                  <td>{parseFloat(invoice.total_with_gst).toFixed(2)}</td>
                  <td>
                    <button
                      className="btn btn-primary"
                      onClick={() => navigate(`/invoice-detail/${invoice.id}`)}

                    >
                      View
                    </button>
                  </td>
                  <td>
                    <button
                      className="downloadbutton"
                      onClick={() => handleDownload(invoice.invoice_number)}
                    >
                      Download
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Address;
