import React, { useEffect, useState, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";

const InvoiceDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [invoice, setInvoice] = useState(null);
  const [deposits, setDeposits] = useState([]);
  const tableRef = useRef();

  useEffect(() => {
    fetch(`http://localhost:8000/api/invoices/${id}/`)
      .then((res) => {
        if (!res.ok) throw new Error("Invoice not found");
        return res.json();
      })
      .then((data) => setInvoice(data))
      .catch((err) => {
        console.error(err);
        setInvoice(null);
      });
  }, [id]);

  const totalDeposited = deposits.reduce((sum, d) => sum + d.deposit_amount, 0);
  const remainingBalance = invoice ? invoice.total_with_gst - totalDeposited : 0;

  const handleGeneratePDF = async () => {
    const element = tableRef.current;
    const canvas = await html2canvas(element);
    const imgData = canvas.toDataURL("image/png");
    const pdf = new jsPDF("p", "mm", "a4");
    const imgProps = pdf.getImageProperties(imgData);
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;

    pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight);
    pdf.save(`Invoice-${invoice.buyer_name}.pdf`);
  };

  if (!invoice) {
    return (
      <div className="p-4 text-center">
        <h2 className="text-xl font-semibold mb-2">No invoice data found.</h2>
        <button onClick={() => navigate(-1)} className="px-4 py-2 bg-red-500 text-white rounded">
          Go Back
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto bg-white rounded shadow-md mt-6 border border-gray-300" style={{ paddingLeft: "100px" }}>
      <h2 className="text-2xl font-bold text-center mb-6 border-b pb-2">Statement - {invoice.buyer_name}</h2>

      {/* Table for Invoice Details */}
      <div ref={tableRef}>
        <table className="w-full border border-gray-300 text-sm text-left mb-6">
          <thead className="bg-gray-200 text-gray-700">
            <tr>
              <th className="border p-2">Date</th>
              <th className="border p-2">Notice</th>
              <th className="border p-2">Amount</th>
              <th className="border p-2">Deposit Date</th>
              <th className="border p-2">Deposit</th>
              <th className="border p-2">Remaining Balance</th>
            </tr>
          </thead>
          <tbody>
            {/* Original Invoice Row */}
            <tr>
              <td className="border p-2">{invoice.invoice_date}</td>
              <td className="border p-2">Initial Bill</td>
              <td className="border p-2">₹{invoice.total_with_gst}</td>
              <td className="border p-2">—</td>
              <td className="border p-2">₹0</td>
              <td className="border p-2 font-bold text-green-600">₹{invoice.total_with_gst}</td>
            </tr>

            {/* Deposit Rows */}
            {deposits.map((d, index) => {
              const remaining = invoice.total_with_gst - deposits
                .slice(0, index + 1)
                .reduce((sum, dep) => sum + dep.deposit_amount, 0);

              return (
                <tr key={index}>
                  <td className="border p-2">—</td>
                  <td className="border p-2">—</td>
                  <td className="border p-2">—</td>
                  <td className="border p-2">{d.deposit_date}</td>
                  <td className="border p-2">₹{d.deposit_amount}</td>
                  <td className="border p-2 font-bold text-green-600">₹{remaining}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Summary Totals */}
      <div className="text-right text-lg font-semibold mb-4">
        <p>Total Deposited: ₹{totalDeposited}</p>
        <p>Remaining Balance: ₹{remainingBalance}</p>
      </div>

      {/* Buttons */}
      <div className="flex flex-col sm:flex-row gap-4 mb-8">
        <button
          onClick={handleGeneratePDF}
          className="w-full sm:w-auto bg-primary hover:bg-secondary text-white font-medium px-6 py-2 rounded"
        >
          📄 Generate PDF
        </button>
        <button
          onClick={() => navigate(-1)}
          className="w-full sm:w-auto bg-primary hover:bg-secondary text-white font-medium px-6 py-2 rounded"
        >
          ← Go Back
        </button>
      </div>
    </div>
  );
};

export default InvoiceDetails;
