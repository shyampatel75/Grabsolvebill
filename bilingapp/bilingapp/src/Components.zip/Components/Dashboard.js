import React, { useRef } from "react";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";

const GenerateInvoice = () => {
  const pdfRef = useRef();

  const getNextInvoiceNumber = async () => {
    try {
      const res = await fetch("http://localhost:8000/api/invoices/");
      const data = await res.json();

      const year = new Date().getFullYear();
      const nextYear = year + 1;
      const financialYear = `${year}-${nextYear}`; // Use dash here

      if (!data.length) return `01/${financialYear}`; // Slash format

      const numbers = data.map((item) => parseInt(item.invoice_number.split("/")[0]));
      const max = Math.max(...numbers);
      const nextNum = String(max + 1).padStart(2, "0");

      return `${nextNum}/${financialYear}`; // Slash format
    } catch (error) {
      console.error("Error getting next invoice number:", error);
      return `01/${new Date().getFullYear()}-${new Date().getFullYear() + 1}`;
    }
  };

  const generatePDF = async () => {
    const input = pdfRef.current;
    if (!input) {
      alert("PDF content not found.");
      return;
    }

    const invoiceNumber = await getNextInvoiceNumber();
    const formData = {
      buyer_name: "Example Buyer",
      total_with_gst: "999.00",
      invoice_number: invoiceNumber,
      invoice_date: new Date().toISOString().split("T")[0],
      financial_year: invoiceNumber.split("/")[1],
    };

    const logoImg = input.querySelector("img");
    if (logoImg && !logoImg.complete) {
      await new Promise((resolve) => {
        logoImg.onload = resolve;
        logoImg.onerror = resolve;
      });
    }

    input.style.visibility = "visible";

    setTimeout(() => {
      html2canvas(input, { scale: 2, useCORS: true }).then((canvas) => {
        const imgData = canvas.toDataURL("image/png");
        const pdf = new jsPDF("p", "mm", "a4");
        const imgWidth = 190;
        const imgHeight = (canvas.height * imgWidth) / canvas.width;

        pdf.addImage(imgData, "PNG", 10, 10, imgWidth, imgHeight);
        pdf.save(`${invoiceNumber}.pdf`);
        input.style.visibility = "hidden";

        // Save to backend
        fetch("http://localhost:8000/api/invoices/", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(formData),
        })
          .then((res) => res.json())
          .then((data) => {
            console.log("Saved invoice:", data);
          })
          .catch((err) => console.error("Save error:", err));
      });
    }, 100);
  };

  return (
    <div className="p-6">
      <button
        onClick={generatePDF}
        className="px-4 py-2 bg-blue-600 text-white rounded-lg"
      >
        Generate Invoice PDF
      </button>

      {/* PDF Content */}
      <div
        ref={pdfRef}
        style={{ visibility: "hidden", width: "800px", padding: "20px", background: "#fff", marginTop: "20px" }}
      >
        <h2>Invoice</h2>
        <p>Buyer: Example Buyer</p>
        <p>Amount: ₹999.00</p>
        <img
          src="http://127.0.0.1:8000/media/logo.png"
          alt="Logo"
          width="120"
          style={{ marginTop: "10px" }}
        />
      </div>
    </div>
  );
};

export default GenerateInvoice;
