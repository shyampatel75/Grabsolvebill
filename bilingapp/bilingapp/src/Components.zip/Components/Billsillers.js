import React from "react";

const Billsfillers = () => {
  return (
    <div className="  border "  style={{  "height" : "100vh" }}>
    <div className="border d-grid gap-2 d-md-flex justify-content-md-end pt-2 pb-2 px-4">
    <button type="button" className="btn btn-primary">Primary</button>
    </div>
     hello
    </div>
  );
};

export default Billsfillers;
 